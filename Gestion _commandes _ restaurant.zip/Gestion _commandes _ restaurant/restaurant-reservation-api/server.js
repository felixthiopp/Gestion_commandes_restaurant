const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');
const restaurantRoutes = require('./routes/restaurantRoutes');
const reservationRoutes = require('./routes/reservationRoutes');
const dishRoutes = require('./routes/dishRoutes');

// Charger les variables d'environnement
dotenv.config();

const app = express();

// Middleware
app.use(express.json());  // Pour analyser le corps des requêtes JSON
app.use(cors());  // Activer CORS pour permettre l'accès depuis d'autres domaines

// Connexion à la base de données MongoDB
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('MongoDB connected');
  })
  .catch((err) => {
    console.error('MongoDB connection error: ', err);
  });

// Routes
app.use('/api/auth', authRoutes);  // Routes d'authentification (inscription, connexion)
app.use('/api/restaurants', restaurantRoutes);  // Routes pour gérer les restaurants
app.use('/api/reservations', reservationRoutes);  // Routes pour gérer les réservations
app.use('/api/dishes', dishRoutes);  // Routes pour gérer les plats

// Route par défaut pour tester si le serveur fonctionne
app.get('/', (req, res) => {
  res.send('API is working');
});

// Démarrer le serveur
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
