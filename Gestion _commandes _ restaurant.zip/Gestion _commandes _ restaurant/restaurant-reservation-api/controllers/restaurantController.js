const Restaurant = require('../models/Restaurant');

// Créer un restaurant (réservé aux utilisateurs avec rôle "restaurant")
exports.createRestaurant = async (req, res) => {
  try {
    if (req.user.role !== 'restaurant') {
      return res.status(403).json({ message: 'Accès refusé' });
    }

    const { name, description, address, menu, availableSlots } = req.body;

    const restaurant = await Restaurant.create({
      owner: req.user.id,
      name,
      description,
      address,
      menu,
      availableSlots
    });

    res.status(201).json(restaurant);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Lister tous les restaurants
exports.getAllRestaurants = async (req, res) => {
  try {
    const restaurants = await Restaurant.find().populate('owner', 'name email');
    res.json(restaurants);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Modifier un restaurant
exports.updateRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id);
    if (!restaurant) return res.status(404).json({ message: 'Restaurant non trouvé' });

    if (restaurant.owner.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Non autorisé à modifier ce restaurant' });
    }

    const updated = await Restaurant.findByIdAndUpdate(req.params.id, req.body, {
      new: true
    });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Supprimer un restaurant
exports.deleteRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id);
    if (!restaurant) return res.status(404).json({ message: 'Restaurant non trouvé' });

    if (restaurant.owner.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Non autorisé à supprimer ce restaurant' });
    }

    await restaurant.deleteOne();
    res.json({ message: 'Restaurant supprimé' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
