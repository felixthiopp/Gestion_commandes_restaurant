const express = require('express');
const router = express.Router();
const Reservation = require('../models/Reservation');
const authMiddleware = require('../middleware/authMiddleware'); // Auth middleware pour protéger les routes

// Route pour créer une réservation
router.post('/reserve', authMiddleware, async (req, res) => {
  const { restaurantId, dishId, date, time, numberOfGuests } = req.body;
  const userId = req.user.userId; // Récupérer l'ID de l'utilisateur connecté

  try {
    const newReservation = new Reservation({
      restaurantId,
      userId,
      dishId, // Associer le plat choisi
      date,
      time,
      numberOfGuests,
    });

    await newReservation.save();
    res.status(201).json({ message: 'Réservation créée avec succès', newReservation });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erreur lors de la réservation', error });
  }
});

module.exports = router;
