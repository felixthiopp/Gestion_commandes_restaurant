const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware'); // Assurez-vous que le middleware JWT est bien en place
const Dish = require('../models/Dish');

// Exemple de route qui nécessite un utilisateur authentifié
router.get('/dishes/:restaurantId', authMiddleware, async (req, res) => {
  const { restaurantId } = req.params;

  try {
    const dishes = await Dish.find({ restaurantId });
    res.status(200).json(dishes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erreur lors de la récupération des plats', error });
  }
});

module.exports = router;
