const express = require('express');
const Dish = require('../models/Dish');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

// Ajouter un plat (accessible uniquement aux administrateurs ou propriétaires de restaurant)
router.post('/', authMiddleware, async (req, res) => {
  const { name, description, price, restaurantId } = req.body;

  try {
    const newDish = new Dish({
      name,
      description,
      price,
      restaurantId,
    });
    await newDish.save();
    res.status(201).json(newDish);
  } catch (error) {
    res.status(400).json({ message: 'Error adding dish', error });
  }
});

// Lister tous les plats d'un restaurant (accessible à tous)
router.get('/:restaurantId', async (req, res) => {
  const { restaurantId } = req.params;

  try {
    const dishes = await Dish.find({ restaurantId });
    res.status(200).json(dishes);
  } catch (error) {
    res.status(400).json({ message: 'Error fetching dishes', error });
  }
});

// Lister tous les plats disponibles (accessible à tous)
router.get('/', async (req, res) => {
  try {
    const dishes = await Dish.find();
    res.status(200).json(dishes);
  } catch (error) {
    res.status(400).json({ message: 'Error fetching dishes', error });
  }
});

module.exports = router;
