# Gestion des Commandes de Restaurant

##  Nom du projet
**Gestion des commandes de restaurant**

##  Technologies utilisées

### Frontend
- **HTML** : Structure de la page web.
- **CSS** : Mise en forme avec un design moderne et responsive.
- **JavaScript** : Interactivité pour gérer les inscriptions, connexions, et réservations.
- **LocalStorage** : Stockage des utilisateurs et des informations de connexion côté client.

### Backend (Évolutif - à implémenter)
- **Node.js + Express** : Pour gérer les utilisateurs, les réservations et les plats.
- **MongoDB** : Base de données pour stocker les informations côté serveur.

##  Fonctionnalités

- Inscription avec nom du restaurant, email et mot de passe.
- Connexion sécurisée avec validation des utilisateurs.
-  Affichage automatique du nom du restaurant après connexion.
-  Formulaire de réservation avec :
  - Choix de la date et de l'heure.
  - Sélection d’un plat parmi une liste.
-  Enregistrement des réservations avec confirmation.
- Déconnexion avec suppression des données locales.

